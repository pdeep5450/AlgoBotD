export default function Home() {
  return (
    <div style={{padding:20}}>
      <h1>AlgoBotD Website Working!</h1>
      <p>Your Next.js Deployment is Ready.</p>
    </div>
  );
}
